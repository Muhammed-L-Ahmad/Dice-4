# dice-roll-4-forms

This is a rails app to simulate a dice roll game using query forms.

Target: https://dice-form.matchthetarget.com

Some rights reserved — see [LICENSE.txt](LICENSE.txt)
